package com.tu.restaurantboard.dao;

public class RestaurantBoardMapperImpl implements RestaurantBoardMapper {

}
