package com.tu.restaurantboard.dao;

public interface RestaurantBoardMapper {

}
