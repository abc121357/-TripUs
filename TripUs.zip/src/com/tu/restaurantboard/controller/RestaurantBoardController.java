package com.tu.restaurantboard.controller;

public class RestaurantBoardController {

}
