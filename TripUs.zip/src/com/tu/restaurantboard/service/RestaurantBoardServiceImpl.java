package com.tu.restaurantboard.service;

public class RestaurantBoardServiceImpl implements RestaurantBoardService{

}
