package com.tu.restaurantboard.service;

public interface RestaurantBoardService {

}
