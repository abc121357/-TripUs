package com.tu.myfavortie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.tu.myfavorite.service.MyfavoriteService;

@Controller
@RequestMapping(value="/department")
public class MyFavoriteController {

	private static final String CONTEXT_PATH="dept";
	
	//의존관계지정
	@Autowired
	private MyfavoriteService myfavoriteService;
	
	
	//@RequestMapping("/listDepartment")
}
