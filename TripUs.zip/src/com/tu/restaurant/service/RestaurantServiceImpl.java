package com.tu.restaurant.service;

public class RestaurantServiceImpl implements RestaurantService {


	
}
