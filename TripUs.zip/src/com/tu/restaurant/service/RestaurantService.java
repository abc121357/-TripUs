package com.tu.restaurant.service;

public interface RestaurantService {

	
	
}
