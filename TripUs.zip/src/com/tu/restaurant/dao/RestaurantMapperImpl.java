package com.tu.restaurant.dao;

public class RestaurantMapperImpl implements RestaurantMapper{

}
