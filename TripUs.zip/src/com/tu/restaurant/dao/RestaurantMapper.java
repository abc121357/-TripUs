package com.tu.restaurant.dao;

public interface RestaurantMapper {

}
