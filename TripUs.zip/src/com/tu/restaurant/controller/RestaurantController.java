package com.tu.restaurant.controller;

public class RestaurantController {

	
	public static void main(String args[]){
		
		int a=0;
		int b=0;
		a=10;
		b=20;
		a=a+b;
		
		System.out.println("a는" + a);
	}
	
}
