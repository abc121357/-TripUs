package com.tu.restaurant.vo;


/**
파일명: TurtcommVO
설 명: 맛집 상세 정보 게시글의 댓글을 위한 VO
작성일: 2019/8/26
작성자: 이한주
*/

public class TurtcommVO {

	
	private String RTNO; // size : 6
	private String RTID; // size : 500
	private String RTNICK; // size : 100
	private String RTPROFILE; // size : 500
	private String RTCONTENT; // size : 300
	private String RTINSERTDATE; // size : date
	private String RTUPDATEDATE; // size : date
	private String RTDELETEYN; // size : 1
	private String RTRECORDINSERTDATE; // size : date
	private String RTRECORDUPDATEDATE; // size : date
	
	
	
	
	public TurtcommVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TurtcommVO(String rTNO, String rTID, String rTNICK, String rTPROFILE, String rTCONTENT, String rTINSERTDATE,
			String rTUPDATEDATE, String rTDELETEYN, String rTRECORDINSERTDATE, String rTRECORDUPDATEDATE) {
		super();
		RTNO = rTNO;
		RTID = rTID;
		RTNICK = rTNICK;
		RTPROFILE = rTPROFILE;
		RTCONTENT = rTCONTENT;
		RTINSERTDATE = rTINSERTDATE;
		RTUPDATEDATE = rTUPDATEDATE;
		RTDELETEYN = rTDELETEYN;
		RTRECORDINSERTDATE = rTRECORDINSERTDATE;
		RTRECORDUPDATEDATE = rTRECORDUPDATEDATE;
	}
	public String getRTNO() {
		return RTNO;
	}
	public void setRTNO(String rTNO) {
		RTNO = rTNO;
	}
	public String getRTID() {
		return RTID;
	}
	public void setRTID(String rTID) {
		RTID = rTID;
	}
	public String getRTNICK() {
		return RTNICK;
	}
	public void setRTNICK(String rTNICK) {
		RTNICK = rTNICK;
	}
	public String getRTPROFILE() {
		return RTPROFILE;
	}
	public void setRTPROFILE(String rTPROFILE) {
		RTPROFILE = rTPROFILE;
	}
	public String getRTCONTENT() {
		return RTCONTENT;
	}
	public void setRTCONTENT(String rTCONTENT) {
		RTCONTENT = rTCONTENT;
	}
	public String getRTINSERTDATE() {
		return RTINSERTDATE;
	}
	public void setRTINSERTDATE(String rTINSERTDATE) {
		RTINSERTDATE = rTINSERTDATE;
	}
	public String getRTUPDATEDATE() {
		return RTUPDATEDATE;
	}
	public void setRTUPDATEDATE(String rTUPDATEDATE) {
		RTUPDATEDATE = rTUPDATEDATE;
	}
	public String getRTDELETEYN() {
		return RTDELETEYN;
	}
	public void setRTDELETEYN(String rTDELETEYN) {
		RTDELETEYN = rTDELETEYN;
	}
	public String getRTRECORDINSERTDATE() {
		return RTRECORDINSERTDATE;
	}
	public void setRTRECORDINSERTDATE(String rTRECORDINSERTDATE) {
		RTRECORDINSERTDATE = rTRECORDINSERTDATE;
	}
	public String getRTRECORDUPDATEDATE() {
		return RTRECORDUPDATEDATE;
	}
	public void setRTRECORDUPDATEDATE(String rTRECORDUPDATEDATE) {
		RTRECORDUPDATEDATE = rTRECORDUPDATEDATE;
	}
	
	
	
}
