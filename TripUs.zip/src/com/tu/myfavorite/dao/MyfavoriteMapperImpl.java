package com.tu.myfavorite.dao;

public class MyfavoriteMapperImpl implements MyfavoriteMapper{

}
