package com.tu.myfavorite.dao;

public interface MyfavoriteMapper {

}
