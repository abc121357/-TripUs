package com.tu.myfavorite.service;

public class MyfavoriteServiceImpl implements MyfavoriteService{

}
