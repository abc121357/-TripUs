package com.tu.myfavorite.service;

public interface MyfavoriteService {

}
