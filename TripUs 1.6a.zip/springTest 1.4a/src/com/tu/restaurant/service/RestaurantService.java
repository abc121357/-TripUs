package com.tu.restaurant.service;


import java.util.List;

import com.tu.restaurant.vo.TurtcommVO;
import com.tu.restaurantboard.vo.TurbboardVO;

public interface RestaurantService {

	public List<TurtcommVO> listRestaurant(TurtcommVO param);
	public List<TurbboardVO> selectseasonbesthit();
}
