package com.tu.myfavorite.service;

import java.util.List;

import com.tu.myfavorite.vo.MyfavoriteVO;

public interface MyfavoriteService {

	public MyfavoriteVO selectmyFavorite(String mygrade);
	
}
