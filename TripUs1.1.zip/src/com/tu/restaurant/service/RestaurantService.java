package com.tu.restaurant.service;

import java.util.ArrayList;
import java.util.List;

import com.tu.restaurant.vo.TurtcommVO;

public interface RestaurantService {

	public List<TurtcommVO> listRestaurant(TurtcommVO param);
	
}
