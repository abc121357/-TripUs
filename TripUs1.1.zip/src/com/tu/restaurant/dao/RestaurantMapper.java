package com.tu.restaurant.dao;

import java.util.ArrayList;
import java.util.List;

import com.tu.restaurant.vo.TurtcommVO;

public interface RestaurantMapper {

	public List<TurtcommVO> listrestaurant(TurtcommVO param);
	
	
}
