package com.tu.restaurant.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tu.restaurant.service.RestaurantService;
import com.tu.restaurant.vo.TurtcommVO;

@Controller
@RequestMapping(value="/restaurant")
public class RestaurantController {

	private static final String CONTEXT_PATH="restaurant";
	
	//set
	
	@Autowired
	private RestaurantService restaurantService;
	
	//매핑
	@RequestMapping("/listrestaurant")
	public ModelAndView listrestaurant(@ModelAttribute TurtcommVO param){
		
		System.out.println("listrestaurant 진입");
		List<TurtcommVO> aList=restaurantService.listRestaurant(param);
		
		ModelAndView mav=new ModelAndView();
		mav.addObject("restaurantlist",aList);
		mav.setViewName(CONTEXT_PATH+"/restaurant");
		
		System.out.println("listDepartment 끝");
		
		return mav;
	}
	
	
	
	
}
