package com.tu.myfavortie.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.tu.myfavorite.service.MyfavoriteService;
import com.tu.myfavorite.vo.MyfavoriteVO;

@Controller
@RequestMapping(value="/myfavorite")
public class MyFavoriteController {

	private static final String CONTEXT_PATH="mypage";
	
	//의존관계지정
	@Autowired
	private MyfavoriteService myfavoriteService;
	
	
	@RequestMapping("/selectmyfavorite")
	public ModelAndView selectmyfavorite(@RequestParam("mygrade") String mygrade){
		System.out.println("selectmyFavorite 진입");
		
		ModelAndView mav= new ModelAndView();
		mav.addObject("myFavoriteVO",myfavoriteService.selectmyFavorite(mygrade));
		mav.addObject("mode","update");
		
		mav.setViewName(CONTEXT_PATH+"/myfavorite");
		
		System.out.println("selectmyFavorite 끝");
		return mav;
	}
	
	
	
}
