package com.tu.restaurantboard.vo;

/**
파일명: TurccommVO
설 명: 맛집 후기 게시글의 댓글을 위한 VO
작성일: 2019/8/26
작성자: LHJ
*/

public class TurccommVO {

	private String RCNO; // size : 6
	private String RCID; // size : 500
	private String RCNICK; // size : 100
	private String RCPROFILE; // size : 500
	private String RCCONTENT; // size : 300
	private String RCINSERTDATE; // size : date
	private String RCUPDATEDATE; // size : date
	private String RCDELETEYN; // size : 1
	private String RCRECORDINSERTDATE; // size : date
	private String RCRECORDUPDATEDATE; // size : date
	
	
	
	public TurccommVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TurccommVO(String rCNO, String rCID, String rCNICK, String rCPROFILE, String rCCONTENT, String rCINSERTDATE,
			String rCUPDATEDATE, String rCDELETEYN, String rCRECORDINSERTDATE, String rCRECORDUPDATEDATE) {
		super();
		RCNO = rCNO;
		RCID = rCID;
		RCNICK = rCNICK;
		RCPROFILE = rCPROFILE;
		RCCONTENT = rCCONTENT;
		RCINSERTDATE = rCINSERTDATE;
		RCUPDATEDATE = rCUPDATEDATE;
		RCDELETEYN = rCDELETEYN;
		RCRECORDINSERTDATE = rCRECORDINSERTDATE;
		RCRECORDUPDATEDATE = rCRECORDUPDATEDATE;
	}
	public String getRCNO() {
		return RCNO;
	}
	public void setRCNO(String rCNO) {
		RCNO = rCNO;
	}
	public String getRCID() {
		return RCID;
	}
	public void setRCID(String rCID) {
		RCID = rCID;
	}
	public String getRCNICK() {
		return RCNICK;
	}
	public void setRCNICK(String rCNICK) {
		RCNICK = rCNICK;
	}
	public String getRCPROFILE() {
		return RCPROFILE;
	}
	public void setRCPROFILE(String rCPROFILE) {
		RCPROFILE = rCPROFILE;
	}
	public String getRCCONTENT() {
		return RCCONTENT;
	}
	public void setRCCONTENT(String rCCONTENT) {
		RCCONTENT = rCCONTENT;
	}
	public String getRCINSERTDATE() {
		return RCINSERTDATE;
	}
	public void setRCINSERTDATE(String rCINSERTDATE) {
		RCINSERTDATE = rCINSERTDATE;
	}
	public String getRCUPDATEDATE() {
		return RCUPDATEDATE;
	}
	public void setRCUPDATEDATE(String rCUPDATEDATE) {
		RCUPDATEDATE = rCUPDATEDATE;
	}
	public String getRCDELETEYN() {
		return RCDELETEYN;
	}
	public void setRCDELETEYN(String rCDELETEYN) {
		RCDELETEYN = rCDELETEYN;
	}
	public String getRCRECORDINSERTDATE() {
		return RCRECORDINSERTDATE;
	}
	public void setRCRECORDINSERTDATE(String rCRECORDINSERTDATE) {
		RCRECORDINSERTDATE = rCRECORDINSERTDATE;
	}
	public String getRCRECORDUPDATEDATE() {
		return RCRECORDUPDATEDATE;
	}
	public void setRCRECORDUPDATEDATE(String rCRECORDUPDATEDATE) {
		RCRECORDUPDATEDATE = rCRECORDUPDATEDATE;
	}
	
	
	
	
	
	
	
}
