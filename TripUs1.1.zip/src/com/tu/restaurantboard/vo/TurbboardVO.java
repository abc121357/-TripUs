package com.tu.restaurantboard.vo;

/**
파일명: TurbboardVO
설 명: 맛집 후기 게시글을 위한 VO
작성일: 2019/8/26
작성자: LHJ
*/

public class TurbboardVO {

	
	private String rbno;
	private String rbtitle;
	private String rbcontent;
	private String rbid;
	private int rbhit;
	private String rbimage;
	private String rbtab;
	private int rblike;
	private String rbInsertDate;
	private String rbUpdateDate;
	private String rbDeleteYN;
	private String rbRecordInsertDate;
	private String RbRecordUpdateDate;
	
	
	
	public TurbboardVO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getRbno() {
		return rbno;
	}
	public void setRbno(String rbno) {
		this.rbno = rbno;
	}
	public String getRbtitle() {
		return rbtitle;
	}
	public void setRbtitle(String rbtitle) {
		this.rbtitle = rbtitle;
	}
	public String getRbcontent() {
		return rbcontent;
	}
	public void setRbcontent(String rbcontent) {
		this.rbcontent = rbcontent;
	}
	public String getRbid() {
		return rbid;
	}
	public void setRbid(String rbid) {
		this.rbid = rbid;
	}
	public int getRbhit() {
		return rbhit;
	}
	public void setRbhit(int rbhit) {
		this.rbhit = rbhit;
	}
	public String getRbimage() {
		return rbimage;
	}
	public void setRbimage(String rbimage) {
		this.rbimage = rbimage;
	}
	public String getRbtab() {
		return rbtab;
	}
	public void setRbtab(String rbtab) {
		this.rbtab = rbtab;
	}
	public int getRblike() {
		return rblike;
	}
	public void setRblike(int rblike) {
		this.rblike = rblike;
	}
	public String getRbInsertDate() {
		return rbInsertDate;
	}
	public void setRbInsertDate(String rbInsertDate) {
		this.rbInsertDate = rbInsertDate;
	}
	public String getRbUpdateDate() {
		return rbUpdateDate;
	}
	public void setRbUpdateDate(String rbUpdateDate) {
		this.rbUpdateDate = rbUpdateDate;
	}
	public String getRbDeleteYN() {
		return rbDeleteYN;
	}
	public void setRbDeleteYN(String rbDeleteYN) {
		this.rbDeleteYN = rbDeleteYN;
	}
	public String getRbRecordInsertDate() {
		return rbRecordInsertDate;
	}
	public void setRbRecordInsertDate(String rbRecordInsertDate) {
		this.rbRecordInsertDate = rbRecordInsertDate;
	}
	public String getRbRecordUpdateDate() {
		return RbRecordUpdateDate;
	}
	public void setRbRecordUpdateDate(String rbRecordUpdateDate) {
		RbRecordUpdateDate = rbRecordUpdateDate;
	}
	
	
	
}
