package com.tu.restaurantboard.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tu.restaurant.vo.TurtcommVO;
import com.tu.restaurantboard.dao.RestaurantBoardMapper;
import com.tu.restaurantboard.vo.TurbboardVO;


@Service
@Transactional
public class RestaurantBoardServiceImpl implements RestaurantBoardService{

	@Autowired
	private RestaurantBoardMapper restaurantBoardMapper;
	
	public List<TurbboardVO>listresBoardList(TurbboardVO param){
	
		List<TurbboardVO> list =new ArrayList<TurbboardVO>();
		list=restaurantBoardMapper.listresBoardList(param);
		return list;
		
	}
	
}
