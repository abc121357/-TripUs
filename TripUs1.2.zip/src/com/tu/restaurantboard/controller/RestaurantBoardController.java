package com.tu.restaurantboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tu.restaurant.vo.TurtcommVO;
import com.tu.restaurantboard.service.RestaurantBoardService;
import com.tu.restaurantboard.vo.TurbboardVO;

public class RestaurantBoardController {

@Controller
@RequestMapping(value="/restaurant")
public class RestaurantController{
	
	private static final String CONTEXT_PATH="restaurant";
	
	//set
	@Autowired
	private RestaurantBoardService restaurantBoardService;

	//매핑
	@RequestMapping("/resBoardList")
	public ModelAndView listrestaurant(@ModelAttribute TurbboardVO param){
		
		System.out.println("listrestaurant 진입");
		List<TurbboardVO> list=restaurantBoardService.listresBoardList(param);
		System.out.println("list내용 콘솔출력 /");
		
		ModelAndView mav=new ModelAndView();
		mav.addObject("listresBoardList",list);
		mav.setViewName(CONTEXT_PATH+"resBoardList");
		
		System.out.println("resBoardList 처리 끝");
		
		return mav;
		
		
	}
	
}
	
}
