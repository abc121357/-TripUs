package com.tu.restaurantboard.dao;

import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.tu.restaurantboard.vo.TurbboardVO;

public class RestaurantBoardMapperImpl extends SqlSessionDaoSupport implements RestaurantBoardMapper {

	public static String CONTEXT_PATH = "com.tu.restaurantboard.resBoardDAO.";
	
	public List<TurbboardVO> listresBoardList(TurbboardVO param){
		
		return getSqlSession().selectList(CONTEXT_PATH+"listrestaurantBoard");
	}
	
}
