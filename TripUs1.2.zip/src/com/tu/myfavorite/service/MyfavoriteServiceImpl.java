package com.tu.myfavorite.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tu.myfavorite.dao.MyfavoriteMapper;
import com.tu.myfavorite.vo.MyfavoriteVO;

@Service
@Transactional
public class MyfavoriteServiceImpl implements MyfavoriteService{

	@Autowired
	private MyfavoriteMapper myfavoriteMapper;
	
	public MyfavoriteVO selectmyFavorite(String mygrade){
		
		
		return myfavoriteMapper.selectmyfavorite(mygrade);
		
	}
	
}
