package com.tu.myfavorite.dao;




import com.tu.myfavorite.vo.MyfavoriteVO;

public interface MyfavoriteMapper {

	public MyfavoriteVO selectmyfavorite(String mygrade);
	
	
}
