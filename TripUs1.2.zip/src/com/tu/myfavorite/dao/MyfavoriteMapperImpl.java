package com.tu.myfavorite.dao;



import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.tu.myfavorite.vo.MyfavoriteVO;



public class MyfavoriteMapperImpl extends SqlSessionDaoSupport implements MyfavoriteMapper{

	
	private final String PACKAGE_PATH = "com.tu.myfavorite.dao.myfavoriteDAO";
	
	@Override
	public MyfavoriteVO selectmyfavorite(String mygrade){
		
		return (MyfavoriteVO)getSqlSession().selectOne(PACKAGE_PATH+ "selectmyfavorite");
	}
	
}
