package com.tu.restaurant.dao;

import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.tu.restaurant.vo.TurtcommVO;


public class RestaurantMapperImpl extends SqlSessionDaoSupport implements RestaurantMapper{

	private final String PACKAGE_PATH = "com.spring.dept.dao.RestaurantDAO.";
	
	@Override
	public List<TurtcommVO> listrestaurant(TurtcommVO param){
		
		return getSqlSession().selectList(PACKAGE_PATH+"listrestaurant");
	}
	
}
