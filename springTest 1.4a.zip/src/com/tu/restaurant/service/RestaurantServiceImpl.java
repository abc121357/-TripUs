package com.tu.restaurant.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.tu.restaurant.dao.RestaurantMapper;
import com.tu.restaurant.vo.TurtcommVO;

@Service
@Transactional
public class RestaurantServiceImpl implements RestaurantService {

	@Autowired
	private RestaurantMapper restaurantMapper;
	
	@Override
	public List<TurtcommVO> listRestaurant(TurtcommVO param){
		
		List<TurtcommVO> aList= new ArrayList<TurtcommVO>();
		aList=restaurantMapper.listrescomment(param);
		return aList;
	}

	
}
