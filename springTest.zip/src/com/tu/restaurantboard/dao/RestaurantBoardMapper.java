package com.tu.restaurantboard.dao;

import java.util.List;

import com.tu.restaurantboard.vo.TurbboardVO;

public interface RestaurantBoardMapper {

	public List<TurbboardVO> listresBoard(TurbboardVO param);
	
}
