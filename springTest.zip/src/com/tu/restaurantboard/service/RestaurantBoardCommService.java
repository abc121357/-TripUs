package com.tu.restaurantboard.service;

import java.util.List;

import com.tu.restaurantboard.vo.TurbboardVO;
import com.tu.restaurantboard.vo.TurccommVO;

public interface RestaurantBoardCommService {

	public List<TurccommVO>listResBoardComm(TurccommVO param);
	
}
