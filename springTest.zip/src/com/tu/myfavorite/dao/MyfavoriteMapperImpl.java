package com.tu.myfavorite.dao;



import java.util.List;

import org.mybatis.spring.support.SqlSessionDaoSupport;

import com.tu.myfavorite.vo.MyfavoriteVO;



public class MyfavoriteMapperImpl extends SqlSessionDaoSupport implements MyfavoriteMapper{

	
	private final String PACKAGE_PATH = "mybatis.query.myfavoriteDAO";
	
	@Override
	public MyfavoriteVO selectmyfavorite(String mygrade){
		
		return getSqlSession().selectOne(PACKAGE_PATH + "selectmyfavorite");
	}
	
}
