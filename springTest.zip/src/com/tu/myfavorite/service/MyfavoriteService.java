package com.tu.myfavorite.service;


import com.tu.myfavorite.vo.MyfavoriteVO;

public interface MyfavoriteService {

	public MyfavoriteVO selectmyFavorite(String mygrade);
	
}
