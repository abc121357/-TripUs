package com.tu.restaurantboard.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.tu.restaurantboard.service.RestaurantBoardService;
import com.tu.restaurantboard.vo.TurbboardVO;


@Controller
@RequestMapping(value="/restaurant")
public class RestaurantBoardController {

	
	private final String CONTEXT_PATH="restaurant";
	
	//set
	@Autowired
	private RestaurantBoardService restaurantBoardService;

	//매핑
	@RequestMapping("/listresBoard")
	public ModelAndView listrestaurantBoard(@ModelAttribute TurbboardVO param){
		
		System.out.println("listrestaurantBoard 진입");
		List<TurbboardVO> list=restaurantBoardService.listresBoardList(param);
		System.out.println("list내용 콘솔출력 /");
		
		for(int i=0; i<list.size(); i++){
			TurbboardVO tVo=(TurbboardVO)list.get(i);
			System.out.println(i+"번째 내역");
			System.out.println("rbid : "+tVo.getRbno());
			System.out.println("rbtitle : "+tVo.getRbtitle());
			System.out.println("rbhit : "+tVo.getRbhit());
			System.out.println("rbinsertdate : " + tVo.getRbinsertdate());
			
		}
		
		ModelAndView mav=new ModelAndView();
		mav.addObject("listresBoardList",list);
		mav.setViewName(CONTEXT_PATH+"/listresBoard");
		
		System.out.println("resBoardList 처리 끝");
		
		return mav;
		
		
	}
	
	@RequestMapping("/insertresBoard")
	public ModelAndView insertBoard(TurbboardVO param){
	int result =restaurantBoardService.insertresBoard(param);
	String resultStr = "등록 완료!!";
		if(result==0)
			resultStr="등록 실패..";
			
		ModelAndView mav=new ModelAndView();
		mav.addObject("result",resultStr);
		mav.setViewName(CONTEXT_PATH+"/insertresBoard");
		return mav;
		
	}
	
}

