package com.tu.myfavorite.dao;




import java.util.List;

import com.tu.myfavorite.vo.MyfavoriteVO;

public interface MyfavoriteMapper {

	public MyfavoriteVO selectmyfavorite(String mygrade);
	
	
}
